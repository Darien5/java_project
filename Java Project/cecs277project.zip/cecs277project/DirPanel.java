package cecs277project;

import java.awt.Dimension;
import java.io.File;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;

public class DirPanel extends JPanel
{
		private static final long serialVersionUID = 3725860681747915637L;
		private JScrollPane scroll = new JScrollPane();
		private JTree dirTree = new JTree();
		private FilePanel filepanel;
		private DefaultTreeModel treemodel;
		boolean modified = false;
		
		@SuppressWarnings("static-access")
		public DirPanel(File f)
		{
			buildTree(f);
			scroll.setViewportView(dirTree);
			scroll.setHorizontalScrollBarPolicy(scroll.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			scroll.setPreferredSize(new Dimension(400, 700));
			add(scroll);
			DefaultTreeCellRenderer renderer = (DefaultTreeCellRenderer) dirTree.getCellRenderer();
			renderer.setLeafIcon(renderer.getClosedIcon());
			dirTree.addTreeSelectionListener(new dirTreeSelectionListener());
		}
		
		public void setFilePanel(FilePanel fp)
		{
			filepanel = fp;
		}
		
		private void buildTree(File f)
	    {
			File rootFile = f;
			DefaultMutableTreeNode root = new DefaultMutableTreeNode(rootFile);
	    	treemodel = new DefaultTreeModel(root);
	    	
	    	DefaultMutableTreeNode dir = null;
	    	File[] dirs = rootFile.listFiles();
			for (int i = 0; i < dirs.length; i++)
			{
				if(!dirs[i].isHidden())
				{
					dir = new DefaultMutableTreeNode(dirs[i].getName());
					root.add(dir);
				}
			}
	    	dirTree.setModel(treemodel);
	    }
		
		private void extendTree(DefaultMutableTreeNode node ,File f) 
		{
			File[] files;
	        DefaultMutableTreeNode parentNode = node;
	        files = f.listFiles();
	        for (File file : files) 
	        {
	            DefaultMutableTreeNode childNode = new DefaultMutableTreeNode(file.getName());
	            parentNode.add(childNode);
	            dirTree.expandPath(new TreePath(childNode.getPath()));
	        }
		}
		
		public void expand()
		{
			dirTree.expandRow(dirTree.getRowForPath(dirTree.getSelectionPath()));
			modified = true;
		}
		
		public void collapse()
		{
			for(int i = dirTree.getMaxSelectionRow(); i < dirTree.getRowForPath(dirTree.getSelectionPath().getParentPath()); i--)
			{
				dirTree.collapseRow(i);
			}
			modified = false;
		}
		
		class dirTreeSelectionListener implements TreeSelectionListener
		{

			@Override
			public void valueChanged(TreeSelectionEvent e) 
			{
				// TODO Auto-generated method stub
				DefaultMutableTreeNode node = (DefaultMutableTreeNode) dirTree.getLastSelectedPathComponent();
				if (!modified)
				{
					String temp = new String();
					TreePath tp = dirTree.getSelectionPath();
					DefaultMutableTreeNode[] tnp = new DefaultMutableTreeNode[tp.getPathCount()];
					System.out.println(dirTree.getRowForPath(tp));
					System.out.println(dirTree.getMaxSelectionRow());
					for(int i = 0; i < tp.getPathCount(); i++)
					{
						tnp[i] = (DefaultMutableTreeNode) tp.getPathComponent(i);
						temp += tnp[i];
						temp += "\\";
					}
					File f = new File(temp);
					if (f.isDirectory())
					{
						extendTree(node, f);
						filepanel.fillList(f);
					}
					else
					{
						@SuppressWarnings("unused")
						ExecuteFile ef = new ExecuteFile(f);
					}
				}
			}
		}
}

