package cecs277project;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.border.EmptyBorder;

public class AboutDig extends JDialog {
	private static final long serialVersionUID = 3725860681747915637L;
	private final JPanel contentPanel = new JPanel();
	private final JLabel text = new JLabel("About");

	/**
	 * Launch the application.
	 */
	
	public AboutDig(java.awt.Frame parent, boolean modal) 
	{
        super(parent, modal);
        getComponents();
        setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setLayout(new FlowLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		setTitle("About");
		contentPanel.add(text, BorderLayout.CENTER);
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.CENTER));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.setActionCommand("OK");
				okButton.addActionListener(new okActionListener());
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
		}
    }
	
	 private class okActionListener implements ActionListener
    {
    	public void actionPerformed(ActionEvent e)
    	{
    		if(e.getActionCommand().equals("OK"))
    		{
    			setVisible(false);
    		}
    	}
    }

}
