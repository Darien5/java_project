package cecs277project;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.border.EmptyBorder;

public class DeleteDig extends JDialog {
	private static final long serialVersionUID = 3725860681747915637L;
	private final JPanel contentPanel = new JPanel();
	private final JLabel text = new JLabel("Are you sure you want to delete this file?");
	File file = null;
	boolean Used = false;

	/**
	 * Launch the application.
	 */
	
	public DeleteDig(java.awt.Frame parent, boolean modal, File f) 
	{
        super(parent, modal);
        getComponents();
        setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		setTitle("Deleting");
		contentPanel.setLayout(null);
		{
			JButton okButton = new JButton("Yes");
			okButton.setBounds(58, 171, 100, 23);
			contentPanel.add(okButton);
			okButton.addActionListener(new okActionListener());
			getRootPane().setDefaultButton(okButton);
		}
		text.setBounds(93, 11, 231, 44);
		contentPanel.add(text);
		file = f;
		JLabel lblNewLabel = new JLabel("Delete " + file.getAbsolutePath());
		lblNewLabel.setBounds(24, 80, 375, 14);
		contentPanel.add(lblNewLabel);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.CENTER));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
		}
		
		JButton btnNewButton = new JButton("No");
		btnNewButton.addActionListener(new okActionListener());
		btnNewButton.setBounds(239, 171, 100, 23);
		contentPanel.add(btnNewButton);
		
		getContentPane().add(contentPanel, BorderLayout.CENTER);
    }
	
	public void setUsed(boolean b)
	{
		Used = b;
	}
	
	public boolean getUsed()
	{
		return Used;
	}
	
	 private class okActionListener implements ActionListener
    {
    	public void actionPerformed(ActionEvent e)
    	{
    		if(e.getActionCommand().equals("Yes"))
    		{
    			setUsed(true);
    		}
    		setVisible(false);
    	}
    }
}
