package cecs277project;



public class FileManager 
{
	public static void main(String[] args) 
	{
        App app = new App();
        app.go();
    }
}
