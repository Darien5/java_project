package cecs277project;

import java.io.File;

import javax.swing.JInternalFrame;
import javax.swing.JSplitPane;

public class FileFrame extends JInternalFrame
{
	private static final long serialVersionUID = 3725860681747915637L;
	JSplitPane splitpane;
	File root = new File("C:\\");
	DirPanel dp;
	FilePanel fp;
	
	public FileFrame()
	{
		dp = new DirPanel(root);
		fp = new FilePanel();
		dp.setFilePanel(fp);
		splitpane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, dp, fp);
		
		this.setTitle(root.getAbsolutePath());
		
		this.getContentPane().add(splitpane);
		this.setMaximizable(true);
		this.setIconifiable(true);
		this.setClosable(true);
		this.setResizable(true);
		this.setSize(420, 420);
		this.setVisible(true);
		this.setAutoscrolls(true);
	}
	
	public void setRoot(File f)
	{
		root = f;
		splitpane.removeAll();
		splitpane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, new DirPanel(root), new FilePanel());
		
		this.setTitle(root.getAbsolutePath());
		
		this.getContentPane().add(splitpane);
		this.setMaximizable(true);
		this.setIconifiable(true);
		this.setClosable(true);
		this.setResizable(true);
		this.setSize(420, 420);
		this.setVisible(true);
		this.setAutoscrolls(true);
	}
	
	public void nameChange()
	{
		this.setName(getFile().getParent());
	}
	
	public void setIcon(Boolean b)
	{
		if (b == true)
		this.setIcon(b);
		else
		this.setIcon(b);
	}
	
	public void setSimp(boolean b)
	{
		if (b == true)
			fp.setSimp(b);
			else
			fp.setSimp(b);
	}
	
	public void requestExpand(Boolean b)
	{
		if (b.equals(true))
		dp.expand();
		else
		dp.collapse();
	}
	
	public boolean getSimp()
	{
		return fp.getSimp();
	}
	
	public void setFile(File f)
	{
		fp.setFile(f);
	}
	
	public File getFile()
	{
		return fp.getFile();
	}
	
	public void setTitle()
	{
		this.setTitle(fp.getFile().toString());
	}
	
	public void updateView()
	{
		setTitle();
		fp.fillList(getFile(), true);
	}
	
}
