package cecs277project;

import java.io.File;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;

public class DIRread 
{
	public String DIRreading(File f)
	{
		File file = f;

		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
		DecimalFormat dformat = new DecimalFormat("#,###");
		if (file.isDirectory())
		{
			return ("Directory: " + file.getAbsolutePath()
					+ " Date: " + formatter.format(file.lastModified())
					+ " Size: " + dformat.format(file.length()));
		}
		else
		{
			return ("File: " + file.getAbsolutePath()
					+ " Date: " + formatter.format(file.lastModified())
					+ " Size: " + dformat.format(file.length()));
		}
	}
}
