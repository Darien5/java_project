package cecs277project;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;

public class ExecuteFile 
{
	ExecuteFile(File f)
	{
		Desktop desktop = Desktop.getDesktop();
		try {
			desktop.open(f);
		} catch (IOException ex) {
			System.out.println(ex.toString());
		}
	}

}
