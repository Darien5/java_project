package cecs277project;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.border.EmptyBorder;

public class PastingDig extends JDialog {
	private static final long serialVersionUID = 3725860681747915637L;
	private final JPanel contentPanel = new JPanel();
	File file;
	private JTextField fromField;
	private JTextField toField;
	String ToString, FromString;
	boolean Used = false;

	/**
	 * Launch the application.
	 */
	
	public PastingDig(java.awt.Frame parent, boolean modal) 
	{
		super(parent, modal);
        getComponents();
        setBounds(100, 100, 450, 200);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		setTitle("Renaming");
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel lblNewLabel = new JLabel("Current Directory: ");
			lblNewLabel.setBounds(10, 11, 117, 14);
			contentPanel.add(lblNewLabel);
		}
		
		JLabel from = new JLabel("Pasting: ");
		from.setBounds(10, 69, 55, 14);
		contentPanel.add(from);
		
		JLabel to = new JLabel("To:");
		to.setBounds(10, 102, 43, 14);
		contentPanel.add(to);
		
		fromField = new JTextField();
		fromField.setBounds(63, 66, 258, 20);
		contentPanel.add(fromField);
		fromField.setColumns(10);
		fromField.setEditable(false);
		
		toField = new JTextField();
		toField.setBounds(63, 99, 258, 20);
		contentPanel.add(toField);
		toField.setColumns(10);
		
		JButton btnNewButton = new JButton("Ok");
		btnNewButton.addActionListener(new okActionListener());
		btnNewButton.setBounds(335, 28, 89, 23);
		contentPanel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Cancel");
		btnNewButton_1.addActionListener(new okActionListener());
		btnNewButton_1.setBounds(335, 65, 89, 23);
		contentPanel.add(btnNewButton_1);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.CENTER));
		}
    }
	
	public void setFrom(String s)
	{
		fromField.setText(s);
	}
	
	public void setUsed(boolean b)
	{
		Used = b;
	}
	
	public boolean getUsed()
	{
		return Used;
	}
	
	public String getTo()
	{
		return toField.getText();
	}
	
	 private class okActionListener implements ActionListener
    {
    	public void actionPerformed(ActionEvent e)
    	{
    		if(e.getActionCommand().equals("Ok"))
    		{
    			setUsed(true);
    		}
    		setVisible(false);
    	}
    }
}
