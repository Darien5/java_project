/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cecs277project;


import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.datatransfer.DataFlavor;
import java.awt.dnd.DnDConstants;
import java.awt.dnd.DragSource;
import java.awt.dnd.DropTarget;
import java.awt.dnd.DropTargetDropEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.DefaultListCellRenderer;
import javax.swing.DefaultListModel;
import javax.swing.Icon;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;
import javax.swing.plaf.metal.MetalIconFactory;


/**
 *
 * @author Dr. Hoffman
 */

@SuppressWarnings("unused")
public class FilePanel extends JPanel 
{
	private static final long serialVersionUID = 3725860681747915637L;
    JScrollPane scroll;
    @SuppressWarnings("rawtypes")
	JList list = new JList();
    @SuppressWarnings("rawtypes")
	DefaultListModel model = new DefaultListModel();
    boolean isSimp = true;
    File f, lastAccess;
    File[] forCell;
    
    @SuppressWarnings("unchecked")
	public FilePanel(){
        this.setDropTarget(new MyDropTarget());
        list.setDragEnabled(true);
        list.setModel(model);
        list.addListSelectionListener(new listSelectionListener());
        DefaultListCellRenderer renderer = (DefaultListCellRenderer) list.getCellRenderer();
        renderer.setIcon(renderer.getDisabledIcon());
        scroll = new JScrollPane(list, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scroll.setPreferredSize(new Dimension(400,700));
        add(scroll);
        
    }
    
    public void setFile(File file)
	{
	    f = file;
	}
    
    public File getFile()
    {
    	return f;
    }
    
    public boolean getSimp()
    {
    	return isSimp;
    }
    
    public void setSimp(boolean b)
    {
    	isSimp = b;
    }
    
    @SuppressWarnings("unchecked")
    public void fillList(File dir, boolean isFile)
    {
    	if (isFile)
    	{
    		File[] files;
        	files = lastAccess.listFiles();
        	forCell = lastAccess.listFiles();
        	model.clear();
        	list.removeAll();
        	DIRread read = new DIRread();
        	for(int i = 0; i< files.length;i++)
        	{
        		if(!files[i].isHidden())
        		{
        			if(!isSimp)
        			model.addElement(read.DIRreading(files[i]));
        			else
        			model.addElement(files[i].getName());
        		}
        	}
        	list.setModel(model);
        	lastAccess = dir;
    	}
    }
    
    @SuppressWarnings("unchecked")
	public void fillList(File dir)
    {
    	File[] files;
    	files = dir.listFiles();
    	forCell = dir.listFiles();
    	model.clear();
    	list.removeAll();
    	DIRread read = new DIRread();
    	for(int i = 0; i< files.length;i++)
    	{
    		if(!files[i].isHidden())
    		{
    			if(!isSimp)
    			model.addElement(read.DIRreading(files[i]));
    			
    			else
    			model.addElement(files[i].getName());
    		}
    	}
    	list.setModel(model);
    	lastAccess = dir;
    }
    
    class listSelectionListener implements ListSelectionListener
	{
		@Override
		public void valueChanged(ListSelectionEvent e) 
		{
			// TODO Auto-generated method stub
			File[] files;
			files = lastAccess.listFiles();
			DIRread read = new DIRread();
			for(int i = 0; i< files.length;i++)
	    	{
	    		if(!files[i].isHidden())
	    		{
	    			if(!isSimp)
	    			{
	    				if(read.DIRreading(files[i]).equals(list.getSelectedValue()))
		    			{
		    				f = files[i];
		    				break;
		    			}
	    			}
	    			else
	    			{
	    				if(files[i].getName().equals(list.getSelectedValue()))
	    				{
	    					f = files[i];
		    				break;
	    				}
	    			}
	    		}
	    	}
		}
	}
    
    /*************************************************************************
     * class MyDropTarget handles the dropping of files onto its owner
     * (whatever JList it is assigned to). As written, it can process two
     * types: strings and files (String, File). The String type is necessary
     * to process internal source drops from another FilePanel object. The
     * File type is necessary to process drops from external sources such 
     * as Windows Explorer or IOS.
     * 
     * Note: no code is provided that actually copies files to the target
     * directory. Also, you may need to adjust this code if your list model
     * is not the default model. JList assumes a toString operation is
     * defined for whatever class is used.
     */
    class MyDropTarget extends DropTarget {
    /**************************************************************************
     * 
     * @param evt the event that caused this drop operation to be invoked
     */    
    	private static final long serialVersionUID = 3725860681747915637L;
        @SuppressWarnings({ "unchecked", "rawtypes" })
		public void drop(DropTargetDropEvent evt){
            try {
                //types of events accepted
                evt.acceptDrop(DnDConstants.ACTION_COPY);
                //storage to hold the drop data for processing
                List result = new ArrayList();
                //what is being dropped? First, Strings are processed
                if(evt.getTransferable().isDataFlavorSupported(DataFlavor.stringFlavor)){     
                    String temp = (String)evt.getTransferable().getTransferData(DataFlavor.stringFlavor);
                    //String events are concatenated if more than one list item 
                    //selected in the source. The strings are separated by
                    //newline characters. Use split to break the string into
                    //individual file names and store in String[]
                    String[] next = temp.split("\\n");
                    //add the strings to the listmodel
                    for(int i=0; i<next.length;i++)
                        model.addElement(next[i]); 
                }
                else{ //then if not String, Files are assumed
                    result =(List)evt.getTransferable().getTransferData(DataFlavor.javaFileListFlavor);
                    //process the input
                    for(Object o : result)
                    {
                        model.addElement(o.toString());
                    }
                }
            }
            catch(Exception ex){
                ex.printStackTrace();
            }
        }
    }
 }
