package cecs277project;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JToolBar;
import javax.swing.SwingUtilities;
import javax.swing.filechooser.FileSystemView;


class App extends JFrame 
{
    // Ignore the next line, VSCODE throws a fit without it
    private static final long serialVersionUID = 3725860681747915637L;
    //
    JPanel panel;
    JButton cancel;
    JButton open;
    JMenuBar menubar, statusbar;
    JPopupMenu popup;
    JToolBar toolbar;
    JMenuItem renamei, copyi, pastei, deletei;
    JDesktopPane desktop;
    File root = new File("C:\\");
    File file;
    @SuppressWarnings("rawtypes")
	JComboBox cb;
    FileFrame ff;
    ArrayList<FileFrame> windowList = new ArrayList<FileFrame>();
    
    public App() 
    {
        panel = new JPanel();
        menubar = new JMenuBar();
        statusbar = new JMenuBar();
        popup = new JPopupMenu();
        desktop = new JDesktopPane();
        panel.setLayout(null);
    }

    public void go() 
    {
    	desktop.setBounds(0,60, 1080,920);
        panel.add(desktop);
        ff = new FileFrame();
        desktop.add(ff);
        windowList.add(ff);
        panel.addMouseListener(new PopupMouseListener());
        
        buildMenu();
    	buildToolbar();
    	buildpopupmenu();
    	buildStatusbar();
        
        this.add(panel);
        this.setSize(1080, 920);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(true);
        setVisible(true);
    }

    public void buildMenu()
    {
    	JMenu file, tree, window, help;
    	file = new JMenu("File");
    	tree = new JMenu("Tree");
    	window = new JMenu("Window");
    	help = new JMenu("Help");
    	
    	JMenuItem rename = new JMenuItem("Rename");
    	JMenuItem copy = new JMenuItem("Copy");
    	JMenuItem delete = new JMenuItem("Delete");
    	JMenuItem run = new JMenuItem("Run");
    	JMenuItem exit = new JMenuItem("Exit");
    	
    	JMenuItem expand = new JMenuItem("Expand Branch");
    	JMenuItem collapse = new JMenuItem("Collapse Branch");
    	
    	JMenuItem newitem = new JMenuItem("New");
    	JMenuItem cascade = new JMenuItem("Cascade");
    	
    	JMenuItem helpitem = new JMenuItem("Help");
    	JMenuItem about = new JMenuItem("About");
    	
    	rename.addActionListener(new RenamingActionListener());
    	copy.addActionListener(new CopyingActionListener());
    	run.addActionListener(new RunActionListener());
    	delete.addActionListener(new DeleteActionListener());
    	exit.addActionListener(new ExitActionListener());
    	
    	expand.addActionListener(new expandActionListener());
    	collapse.addActionListener(new collapseActionListener());
    	
    	newitem.addActionListener(new newActionListener());
    	cascade.addActionListener(new cascadeActionListener());
    	
    	helpitem.addActionListener(new HelpActionListener());
    	about.addActionListener(new AboutActionListener());
    	
    	file.add(rename);
    	file.add(copy);
    	file.add(delete);
    	file.add(run);
    	file.add(exit);
    	
    	tree.add(expand);
    	tree.add(collapse);
    	
    	window.add(newitem);
    	window.add(cascade);
    	
    	help.add(helpitem);
    	help.add(about);
    	
    	menubar.add(file);
    	menubar.add(tree);
    	menubar.add(window);
    	menubar.add(help);
    	menubar.setBounds(0,0,1080, 30);
    	panel.add(menubar);
    }
    
    private void buildStatusbar()
    {
    	statusbar.removeAll();
    	desktop.remove(statusbar);
    	JLabel size = new JLabel("Current Drive:"+ root.toString() + " Used Space:" + (root.getTotalSpace() - root.getFreeSpace())/1000000000 + "GB Free Space:" + root.getFreeSpace()/1000000000 +"GB Total Space:" + root.getTotalSpace()/1000000000 + "GB") ;
    	statusbar.add(size);
    	statusbar.setBounds(0, 800, 1080, 20);
    	//statusbar.setSize(1080, 20);
    	statusbar.setVisible(true);
    	desktop.add(statusbar, BorderLayout.SOUTH);
    }
    
    @SuppressWarnings({ "unchecked", "rawtypes" })
	private void buildToolbar()
    {
    	toolbar = new JToolBar();
    	File[] files;
    	files = File.listRoots();
    	String[] arr = new String[files.length];
    	for(int i = 0; i< files.length; i++)
    	{
    		arr[i] = files[i].toString() + " " + FileSystemView.getFileSystemView().getSystemDisplayName(files[i]);
    	}
    	cb = new JComboBox(arr);
    	toolbar.add(cb);
    	cb.addActionListener(new ToolActionListener());
    	toolbar.setPreferredSize(new Dimension(200,30));
    	
    	toolbar.addSeparator();
    	JButton details = new JButton("Details");
    	toolbar.add(details);
    	details.addActionListener(new DetailsActionListener());
    	toolbar.addSeparator();
    	JButton simple = new JButton("Simple");
    	toolbar.add(simple);
    	simple.addActionListener(new SimpActionListener());
    	toolbar.setBounds(390, 30, 300, 30);
    	toolbar.setFloatable(false);
    	panel.add(toolbar);
    }
    
    private void buildpopupmenu()
    {
    	renamei = new JMenuItem("Rename");
    	copyi = new JMenuItem("Copy");
    	pastei = new JMenuItem("Paste");
    	deletei = new JMenuItem("Delete");
    	
    	popup.add(renamei);
    	popup.add(copyi);
    	popup.add(pastei);
    	popup.add(deletei);
    	
    	renamei.addActionListener(new RenamingActionListener());
    	copyi.addActionListener(new CopyingActionListener());
    	pastei.addActionListener(new PastingActionListener());
    	deletei.addActionListener(new DeleteActionListener());
    }
    
    public void activatePopUp(MouseEvent e)
    {
    	panel.add(popup);
		popup.setVisible(true);
		popup.show(e.getComponent(), e.getX(), e.getY());
    }
    
    private class RenamingActionListener implements ActionListener
    {
    	public void actionPerformed(ActionEvent e)
    	{
    		if (ff.getFile() != null)
    		{
				//throw new UnsupportedOperationException("Not supported yet.");
	    		RenamingDig dig = new RenamingDig(null, true);
	    		dig.setFrom(ff.getFile().getName());
	    		dig.setVisible(true);
	    		String toField = dig.getTo();
	    		File temp = new File(ff.getFile().getParent()+"\\"+toField);
	    		if(dig.getUsed() && !toField.isEmpty())
	    		{
	    			try 
	        		{
						Files.move(ff.getFile().toPath(), temp.toPath(), StandardCopyOption.REPLACE_EXISTING);
						dig.setUsed(false);
	        		} 
	        		catch (IOException e1) 
	        		{
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
	    		}
	    		ff.setFile(temp);
	    		ff.updateView();
    		}
    	}
    }
    
    private class CopyingActionListener implements ActionListener
    {
    	public void actionPerformed(ActionEvent e)
    	{
    		//throw new UnsupportedOperationException("Not supported yet.");
    		if (ff.getFile() != null)
    		{
    			CopyingDig dig = new CopyingDig(null, true);
        		dig.setFrom(ff.getFile().getPath());
        		dig.setVisible(true);
        		String toField = dig.getTo();
        		File temp = new File(toField);
        		if (dig.getUsed() && !toField.isEmpty())
        		{
        			try
            		{
            			Files.copy(ff.getFile().toPath(), temp.toPath(), StandardCopyOption.COPY_ATTRIBUTES);
            			dig.setUsed(false);
            		}
            		catch(IOException ioe)
            		{
            			System.out.println("Error");
            		}
        		}
        		ff.setFile(temp);
        		ff.updateView();
    		}
    	}
    }
    
    private class PastingActionListener implements ActionListener
    {
    	public void actionPerformed(ActionEvent e)
    	{
    		if (ff.getFile() != null)
    		{
    			PastingDig dig = new PastingDig(null, true);
    			dig.setFrom(ff.getFile().getName());
        		dig.setVisible(true);
        		String toField = dig.getTo();
        		File temp = new File(toField + "\\" +ff.getFile().getName());
        		if (dig.getUsed() && !toField.isEmpty())
        		{
        			try
            		{
            			Files.copy(ff.getFile().toPath(), temp.toPath(), StandardCopyOption.COPY_ATTRIBUTES);
            			dig.setUsed(false);
            		}
            		catch(IOException ioe)
            		{
            			System.out.println("Error");
            		}
        		}
        		ff.setFile(temp);
        		ff.updateView();
    		}
    	}
    }
    
    private class DeleteActionListener implements ActionListener
    {
    	public void actionPerformed(ActionEvent e)
    	{
    		//throw new UnsupportedOperationException("Not supported yet.");
    		DeleteDig dig = new DeleteDig(null, true, ff.getFile());
    		dig.setVisible(true);
    		if(dig.getUsed())
    		{
    			try 
    			{
					Files.delete(ff.getFile().toPath());
					dig.setUsed(false);
				} 
    			catch (IOException e1)
    			{
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
    		}
    		ff.updateView();
    	}
    }
   
    private class RunActionListener implements ActionListener
    {
    	public void actionPerformed(ActionEvent e)
    	{
    		if(e.getActionCommand().equals("Run"))
    		{
    			@SuppressWarnings("unused")
				ExecuteFile ef = new ExecuteFile(ff.getFile());
    		}
    		else
    		{
    			System.out.println("Debugging the program");
    		}
    	}
    }
    
    private class ExitActionListener implements ActionListener
    {
    	public void actionPerformed(ActionEvent e)
    	{
    		System.exit(0);
    	}
    }
    
    private class expandActionListener implements ActionListener
    {
    	public void actionPerformed(ActionEvent e)
    	{
    		ff.requestExpand(true);
    	}
    }
    
    private class collapseActionListener implements ActionListener
    {
    	public void actionPerformed(ActionEvent e)
    	{
    		ff.requestExpand(false);
    	}
    }
    
    private class newActionListener implements ActionListener
    {
    	public void actionPerformed(ActionEvent e)
    	{
    		//throw new UnsupportedOperationException("Not supported yet.");
    		panel.add(desktop);
            ff = new FileFrame();
            desktop.add(ff);
            windowList.add(ff);
    	}
    }
    
    public App getApp()
    {
    	return this;
    }
    
    private class cascadeActionListener implements ActionListener
    {
    	public void actionPerformed(ActionEvent e)
    	{
    		if(windowList.size()>0)
    		{
    			for(int i = 0; i<windowList.size(); i++)
    			{
    				windowList.get(i).setLocation((50*(windowList.size()-i-1)),(50*(windowList.size()-i-1)));
    			}
    		}
    	}
    }
    
    private class HelpActionListener implements ActionListener
    {
    	public void actionPerformed(ActionEvent e)
    	{
    		//throw new UnsupportedOperationException("Not supported yet.");
    		HelpDig dig = new HelpDig(null, true);
    		dig.setVisible(true);
    	}
    }
    
    private class AboutActionListener implements ActionListener
    {
    	public void actionPerformed(ActionEvent e)
    	{
    		//throw new UnsupportedOperationException("Not supported yet.");
    		AboutDig dig = new AboutDig(null, true);
    		dig.setVisible(true);
    	}
    }
    
    private class SimpActionListener implements ActionListener
    {
    	public void actionPerformed(ActionEvent e)
    	{
    		ff.setSimp(true);
    	}
    }
    
    private class DetailsActionListener implements ActionListener
    {
    	public void actionPerformed(ActionEvent e)
    	{
    		ff.setSimp(false);
    	}
    }
    
    private class ToolActionListener implements ActionListener
    {
    	public void actionPerformed(ActionEvent e)
    	{
    		//throw new UnsupportedOperationException("Not supported yet.");
    		String s = (String) cb.getSelectedItem();
    		File[] files;
    		files = File.listRoots();
    		for(File temp: files)
    		{
    			if(s.contains(temp.toString()))
    			{
    				System.out.println(temp.toString());
    				ff.setRoot(temp);
    				root = temp;
    			}
    		}
    		buildStatusbar();
    	}
    }
    
    private class PopupMouseListener implements MouseListener
    {
		@Override
		public void mouseClicked(MouseEvent e) 
		{
			if(SwingUtilities.isRightMouseButton(e))
			{
				activatePopUp(e);
			}
		}

		@Override
		public void mousePressed(MouseEvent e) 
		{
			// TODO Auto-generated method stub
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseEntered(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseExited(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}
    }
}